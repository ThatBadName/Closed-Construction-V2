const { emojis } = require('../constants')

module.exports = []