// {
//     name: '',
//     description: '',
//     pay: 0,
//     levelRequired: 0,
// },

module.exports = [
    {
        name: 'Cook',
        description: 'Cook up some good food for yourself',
        pay: 5000,
        levelRequired: 0,
    },
    {
        name: 'Hunter',
        description: 'Hunt some animals for coins',
        pay: 10000,
        levelRequired: 5,
    },
    {
        name: 'YouTuber',
        description: 'Make videos for others to enjoy',
        pay: 15000,
        levelRequired: 10,
    },
    {
        name: 'Discord Mod',
        description: 'Moderate chats 25 hours a day',
        pay: 20000,
        levelRequired: 17,
    },
    {
        name: 'Zoo Keeper',
        description: 'Keep animals happy',
        pay: 30000,
        levelRequired: 26,
    },
    {
        name: 'Architect',
        description: 'You make money out of buildings',
        pay: 50000,
        levelRequired: 35,
    },
    {
        name: 'Discord Admin',
        description: 'POWERRR',
        pay: 70000,
        levelRequired: 39
    },
    {
        name: 'Thief',
        description: 'You rob things and make a good bit of money out of it',
        pay: 100000,
        levelRequired: 45,
    },
    {
        name: 'Astronaut',
        description: 'You\'re a space explorer',
        pay: 250000,
        levelRequired: 55,
    },
    {
        name: 'CEO of stupidity',
        description: 'This will pay for iHate\'s cheese',
        pay: 500000,
        levelRequired: 60,
    },
    {
        name: 'Developer',
        description: 'Sit and code for hours',
        pay: 2000000,
        levelRequired: 190,
    },
    
]